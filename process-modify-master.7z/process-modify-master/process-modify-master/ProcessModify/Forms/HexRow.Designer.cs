﻿namespace ProcessModify
{
    partial class HexRow
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_start_address = new System.Windows.Forms.Label();
            this.tb2 = new System.Windows.Forms.TextBox();
            this.tb1 = new System.Windows.Forms.TextBox();
            this.tb0 = new System.Windows.Forms.TextBox();
            this.tb5 = new System.Windows.Forms.TextBox();
            this.tb4 = new System.Windows.Forms.TextBox();
            this.tb3 = new System.Windows.Forms.TextBox();
            this.tbB = new System.Windows.Forms.TextBox();
            this.tbA = new System.Windows.Forms.TextBox();
            this.tb9 = new System.Windows.Forms.TextBox();
            this.tb8 = new System.Windows.Forms.TextBox();
            this.tb7 = new System.Windows.Forms.TextBox();
            this.tb6 = new System.Windows.Forms.TextBox();
            this.tbF = new System.Windows.Forms.TextBox();
            this.tbE = new System.Windows.Forms.TextBox();
            this.tbD = new System.Windows.Forms.TextBox();
            this.tbC = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_start_address
            // 
            this.lbl_start_address.AutoSize = true;
            this.lbl_start_address.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_start_address.Location = new System.Drawing.Point(-2, 3);
            this.lbl_start_address.Name = "lbl_start_address";
            this.lbl_start_address.Size = new System.Drawing.Size(55, 15);
            this.lbl_start_address.TabIndex = 0;
            this.lbl_start_address.Text = "000000";
            // 
            // tb2
            // 
            this.tb2.BackColor = System.Drawing.Color.Gainsboro;
            this.tb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb2.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb2.ForeColor = System.Drawing.Color.Black;
            this.tb2.Location = new System.Drawing.Point(115, 0);
            this.tb2.Name = "tb2";
            this.tb2.ReadOnly = true;
            this.tb2.Size = new System.Drawing.Size(24, 21);
            this.tb2.TabIndex = 10;
            this.tb2.Text = "0F";
            this.tb2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb2.Click += new System.EventHandler(this.tb2_Click);
            // 
            // tb1
            // 
            this.tb1.BackColor = System.Drawing.Color.Gainsboro;
            this.tb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb1.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb1.ForeColor = System.Drawing.Color.Black;
            this.tb1.Location = new System.Drawing.Point(91, 0);
            this.tb1.Name = "tb1";
            this.tb1.ReadOnly = true;
            this.tb1.Size = new System.Drawing.Size(24, 21);
            this.tb1.TabIndex = 9;
            this.tb1.Text = "0F";
            this.tb1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb1.Click += new System.EventHandler(this.tb1_Click);
            this.tb1.TextChanged += new System.EventHandler(this.Tb1_TextChanged);
            // 
            // tb0
            // 
            this.tb0.BackColor = System.Drawing.Color.Gainsboro;
            this.tb0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb0.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb0.ForeColor = System.Drawing.Color.Black;
            this.tb0.Location = new System.Drawing.Point(67, 0);
            this.tb0.MaxLength = 2;
            this.tb0.Name = "tb0";
            this.tb0.ReadOnly = true;
            this.tb0.Size = new System.Drawing.Size(24, 21);
            this.tb0.TabIndex = 8;
            this.tb0.Text = "0F";
            this.tb0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb0.Click += new System.EventHandler(this.tb0_Click);
            // 
            // tb5
            // 
            this.tb5.BackColor = System.Drawing.Color.Gainsboro;
            this.tb5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb5.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb5.ForeColor = System.Drawing.Color.Black;
            this.tb5.Location = new System.Drawing.Point(187, 0);
            this.tb5.Name = "tb5";
            this.tb5.ReadOnly = true;
            this.tb5.Size = new System.Drawing.Size(24, 21);
            this.tb5.TabIndex = 13;
            this.tb5.Text = "0F";
            this.tb5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb5.Click += new System.EventHandler(this.tb5_Click);
            // 
            // tb4
            // 
            this.tb4.BackColor = System.Drawing.Color.Gainsboro;
            this.tb4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb4.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb4.ForeColor = System.Drawing.Color.Black;
            this.tb4.Location = new System.Drawing.Point(163, 0);
            this.tb4.Name = "tb4";
            this.tb4.ReadOnly = true;
            this.tb4.Size = new System.Drawing.Size(24, 21);
            this.tb4.TabIndex = 12;
            this.tb4.Text = "0F";
            this.tb4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb4.Click += new System.EventHandler(this.tb4_Click);
            // 
            // tb3
            // 
            this.tb3.BackColor = System.Drawing.Color.Gainsboro;
            this.tb3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb3.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb3.ForeColor = System.Drawing.Color.Black;
            this.tb3.Location = new System.Drawing.Point(139, 0);
            this.tb3.Name = "tb3";
            this.tb3.ReadOnly = true;
            this.tb3.Size = new System.Drawing.Size(24, 21);
            this.tb3.TabIndex = 11;
            this.tb3.Text = "0F";
            this.tb3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb3.Click += new System.EventHandler(this.tb3_Click);
            // 
            // tbB
            // 
            this.tbB.BackColor = System.Drawing.Color.Gainsboro;
            this.tbB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbB.Cursor = System.Windows.Forms.Cursors.Default;
            this.tbB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbB.ForeColor = System.Drawing.Color.Black;
            this.tbB.Location = new System.Drawing.Point(331, 0);
            this.tbB.Name = "tbB";
            this.tbB.ReadOnly = true;
            this.tbB.Size = new System.Drawing.Size(24, 21);
            this.tbB.TabIndex = 19;
            this.tbB.Text = "0F";
            this.tbB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbB.Click += new System.EventHandler(this.tbB_Click);
            // 
            // tbA
            // 
            this.tbA.BackColor = System.Drawing.Color.Gainsboro;
            this.tbA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbA.Cursor = System.Windows.Forms.Cursors.Default;
            this.tbA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbA.ForeColor = System.Drawing.Color.Black;
            this.tbA.Location = new System.Drawing.Point(307, 0);
            this.tbA.Name = "tbA";
            this.tbA.ReadOnly = true;
            this.tbA.Size = new System.Drawing.Size(24, 21);
            this.tbA.TabIndex = 18;
            this.tbA.Text = "0F";
            this.tbA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbA.Click += new System.EventHandler(this.tbA_Click);
            // 
            // tb9
            // 
            this.tb9.BackColor = System.Drawing.Color.Gainsboro;
            this.tb9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb9.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb9.ForeColor = System.Drawing.Color.Black;
            this.tb9.Location = new System.Drawing.Point(283, 0);
            this.tb9.Name = "tb9";
            this.tb9.ReadOnly = true;
            this.tb9.Size = new System.Drawing.Size(24, 21);
            this.tb9.TabIndex = 17;
            this.tb9.Text = "0F";
            this.tb9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb9.Click += new System.EventHandler(this.tb9_Click);
            // 
            // tb8
            // 
            this.tb8.BackColor = System.Drawing.Color.Gainsboro;
            this.tb8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb8.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb8.ForeColor = System.Drawing.Color.Black;
            this.tb8.Location = new System.Drawing.Point(259, 0);
            this.tb8.Name = "tb8";
            this.tb8.ReadOnly = true;
            this.tb8.Size = new System.Drawing.Size(24, 21);
            this.tb8.TabIndex = 16;
            this.tb8.Text = "0F";
            this.tb8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb8.Click += new System.EventHandler(this.tb8_Click);
            // 
            // tb7
            // 
            this.tb7.BackColor = System.Drawing.Color.Gainsboro;
            this.tb7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb7.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb7.ForeColor = System.Drawing.Color.Black;
            this.tb7.Location = new System.Drawing.Point(235, 0);
            this.tb7.Name = "tb7";
            this.tb7.ReadOnly = true;
            this.tb7.Size = new System.Drawing.Size(24, 21);
            this.tb7.TabIndex = 15;
            this.tb7.Text = "0F";
            this.tb7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb7.Click += new System.EventHandler(this.tb7_Click);
            // 
            // tb6
            // 
            this.tb6.BackColor = System.Drawing.Color.Gainsboro;
            this.tb6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb6.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb6.ForeColor = System.Drawing.Color.Black;
            this.tb6.Location = new System.Drawing.Point(211, 0);
            this.tb6.Name = "tb6";
            this.tb6.ReadOnly = true;
            this.tb6.Size = new System.Drawing.Size(24, 21);
            this.tb6.TabIndex = 14;
            this.tb6.Text = "0F";
            this.tb6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb6.Click += new System.EventHandler(this.tb6_Click);
            // 
            // tbF
            // 
            this.tbF.BackColor = System.Drawing.Color.Gainsboro;
            this.tbF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbF.Cursor = System.Windows.Forms.Cursors.Default;
            this.tbF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbF.ForeColor = System.Drawing.Color.Black;
            this.tbF.Location = new System.Drawing.Point(427, 0);
            this.tbF.Name = "tbF";
            this.tbF.ReadOnly = true;
            this.tbF.Size = new System.Drawing.Size(24, 21);
            this.tbF.TabIndex = 23;
            this.tbF.Text = "0F";
            this.tbF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbF.Click += new System.EventHandler(this.tbF_Click);
            // 
            // tbE
            // 
            this.tbE.BackColor = System.Drawing.Color.Gainsboro;
            this.tbE.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbE.Cursor = System.Windows.Forms.Cursors.Default;
            this.tbE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbE.ForeColor = System.Drawing.Color.Black;
            this.tbE.Location = new System.Drawing.Point(403, 0);
            this.tbE.Name = "tbE";
            this.tbE.ReadOnly = true;
            this.tbE.Size = new System.Drawing.Size(24, 21);
            this.tbE.TabIndex = 22;
            this.tbE.Text = "0F";
            this.tbE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbE.Click += new System.EventHandler(this.tbE_Click);
            // 
            // tbD
            // 
            this.tbD.BackColor = System.Drawing.Color.Gainsboro;
            this.tbD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbD.Cursor = System.Windows.Forms.Cursors.Default;
            this.tbD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbD.ForeColor = System.Drawing.Color.Black;
            this.tbD.Location = new System.Drawing.Point(379, 0);
            this.tbD.Name = "tbD";
            this.tbD.ReadOnly = true;
            this.tbD.Size = new System.Drawing.Size(24, 21);
            this.tbD.TabIndex = 21;
            this.tbD.Text = "0F";
            this.tbD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbD.Click += new System.EventHandler(this.tbD_Click);
            // 
            // tbC
            // 
            this.tbC.BackColor = System.Drawing.Color.Gainsboro;
            this.tbC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbC.Cursor = System.Windows.Forms.Cursors.Default;
            this.tbC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbC.ForeColor = System.Drawing.Color.Black;
            this.tbC.Location = new System.Drawing.Point(355, 0);
            this.tbC.Name = "tbC";
            this.tbC.ReadOnly = true;
            this.tbC.Size = new System.Drawing.Size(24, 21);
            this.tbC.TabIndex = 20;
            this.tbC.Text = "0F";
            this.tbC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbC.Click += new System.EventHandler(this.tbC_Click);
            // 
            // HexRow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tbF);
            this.Controls.Add(this.tbE);
            this.Controls.Add(this.tbD);
            this.Controls.Add(this.tbC);
            this.Controls.Add(this.tbB);
            this.Controls.Add(this.tbA);
            this.Controls.Add(this.tb9);
            this.Controls.Add(this.tb8);
            this.Controls.Add(this.tb7);
            this.Controls.Add(this.tb6);
            this.Controls.Add(this.tb5);
            this.Controls.Add(this.tb4);
            this.Controls.Add(this.tb3);
            this.Controls.Add(this.tb2);
            this.Controls.Add(this.tb1);
            this.Controls.Add(this.tb0);
            this.Controls.Add(this.lbl_start_address);
            this.Name = "HexRow";
            this.Size = new System.Drawing.Size(455, 22);
            this.Load += new System.EventHandler(this.HexRow_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_start_address;
        private System.Windows.Forms.TextBox tb2;
        private System.Windows.Forms.TextBox tb1;
        private System.Windows.Forms.TextBox tb0;
        private System.Windows.Forms.TextBox tb5;
        private System.Windows.Forms.TextBox tb4;
        private System.Windows.Forms.TextBox tb3;
        private System.Windows.Forms.TextBox tbB;
        private System.Windows.Forms.TextBox tbA;
        private System.Windows.Forms.TextBox tb9;
        private System.Windows.Forms.TextBox tb8;
        private System.Windows.Forms.TextBox tb7;
        private System.Windows.Forms.TextBox tb6;
        private System.Windows.Forms.TextBox tbF;
        private System.Windows.Forms.TextBox tbE;
        private System.Windows.Forms.TextBox tbD;
        private System.Windows.Forms.TextBox tbC;
    }
}

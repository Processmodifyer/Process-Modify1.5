**Process Modify**
<br>
Process Modify is an application that allows convenient editing of a selected process's RAM.  You can observe the effects on a process as you change its variables gradually.
<br><br>
Its main use for me was learning about the inner workings of N64 ROMs, but it could be useful for other things.

Some Videos and Screenshots:<br>
Video (2:45)<br>
[![ScreenShot](http://img.youtube.com/vi/SKN5lbidbXc/0.jpg)](https://www.youtube.com/watch?v=SKN5lbidbXc)

Video (3:01)<br>
[![ScreenShot](http://img.youtube.com/vi/AclNAJOJo1o/0.jpg)](https://www.youtube.com/watch?v=AclNAJOJo1o)

![Alt text](SCREENSHOTS/pm0.png?raw=true "Screenshot 1")<br>

![Alt text](SCREENSHOTS/pm2.png?raw=true "Screenshot 2")<br>

![Alt text](SCREENSHOTS/pm3.png?raw=true "Screenshot 3")
